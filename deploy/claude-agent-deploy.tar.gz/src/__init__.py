"""Claude Agent System - Automated task execution using Claude Code."""

__version__ = "1.0.0"
__author__ = "Claude Agent System"