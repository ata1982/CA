# AI News Site

Claude APIを活用した自動ニュース収集・配信システム

## 機能

- **自動ニュース収集**: 複数のニュースソースから記事を自動クローリング
- **AI記事処理**: Claude APIによる記事の要約・カテゴリ分類
- **レスポンシブWebサイト**: モダンなデザインのニュース配信サイト
- **リアルタイム更新**: 24時間自動でニュースを更新

## 技術スタック

### Backend
- **FastAPI**: 高性能なPython Webフレームワーク
- **SQLAlchemy**: ORMとデータベース管理
- **PostgreSQL**: メインデータベース（開発時はSQLite）
- **httpx**: 非同期HTTPクライアント
- **BeautifulSoup4**: HTMLパーシング

### Frontend
- **HTML5/CSS3**: レスポンシブデザイン
- **Jinja2**: テンプレートエンジン
- **Google Fonts**: Noto Sans JP

### Infrastructure
- **Docker Compose**: 開発環境管理
- **uvicorn**: ASGIサーバー

## プロジェクト構造

```
news-ai-site/
├── backend/
│   ├── app.py          # FastAPIアプリケーション
│   ├── models.py       # データベースモデル
│   ├── crawler.py      # ニュースクローラー
│   ├── ai_processor.py # Claude API連携
│   └── requirements.txt
├── frontend/
│   ├── index.html      # トップページ
│   ├── article.html    # 記事詳細ページ
│   └── style.css       # スタイルシート
├── database/
│   └── schema.sql      # データベーススキーマ
├── docker-compose.yml  # Docker設定
├── Dockerfile
└── README.md
```

## セットアップ

### 1. 環境変数設定

```bash
export ANTHROPIC_API_KEY="your_claude_api_key_here"
```

### 2. Docker環境での起動

```bash
# 全サービス起動
docker-compose up -d

# ログ確認
docker-compose logs -f

# 停止
docker-compose down
```

### 3. ローカル環境での起動

```bash
# 仮想環境作成
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 依存関係インストール
pip install -r backend/requirements.txt

# データベース初期化（SQLite使用）
cd backend
python -c "
from models import Base
from sqlalchemy import create_engine
engine = create_engine('sqlite:///news.db')
Base.metadata.create_all(engine)
"

# アプリケーション起動
uvicorn app:app --reload

# 別ターミナルでクローラー実行
python crawler.py

# AI処理実行
python ai_processor.py
```

## API エンドポイント

### 記事関連
- `GET /` - トップページ
- `GET /article/{id}` - 記事詳細
- `GET /api/articles` - 記事一覧API
- `POST /api/articles` - 記事作成
- `GET /api/articles?category_id={id}` - カテゴリ別記事

### カテゴリ関連
- `GET /api/categories` - カテゴリ一覧
- `POST /api/categories` - カテゴリ作成

## データベーススキーマ

### categories
- `id`: プライマリキー
- `name`: カテゴリ名
- `description`: 説明
- `created_at`: 作成日時

### articles
- `id`: プライマリキー
- `title`: タイトル
- `content`: 本文
- `summary`: AI生成要約
- `original_url`: 元記事URL
- `author`: 著者
- `published_at`: 公開日時
- `category_id`: カテゴリID
- `view_count`: 閲覧数
- `is_published`: 公開フラグ

### crawl_sources
- `id`: プライマリキー
- `name`: ソース名
- `url`: クローリング対象URL
- `selector`: CSSセレクタ
- `is_active`: アクティブフラグ
- `last_crawled`: 最終クローリング日時

## 開発ガイド

### 新しいニュースソースの追加

1. `crawl_sources`テーブルに新しいソースを追加
2. 必要に応じて`crawler.py`のセレクタロジックを調整

### Claude API設定

1. [Anthropic Console](https://console.anthropic.com/)でAPIキーを取得
2. 環境変数`ANTHROPIC_API_KEY`に設定
3. `ai_processor.py`でプロンプトをカスタマイズ可能

### フロントエンドカスタマイズ

- `frontend/style.css`: デザイン調整
- `frontend/index.html`, `frontend/article.html`: レイアウト変更

## 本番環境での注意事項

1. **セキュリティ**
   - APIキーの適切な管理
   - データベース認証情報の保護
   - HTTPS設定

2. **パフォーマンス**
   - データベースインデックスの最適化
   - 画像配信のCDN活用
   - キャッシュ戦略

3. **監視**
   - ログ監視
   - エラー通知
   - パフォーマンス監視

## トラブルシューティング

### よくある問題

1. **Claude API接続エラー**
   ```bash
   # APIキー確認
   echo $ANTHROPIC_API_KEY
   ```

2. **データベース接続エラー**
   ```bash
   # PostgreSQL接続確認
   docker-compose logs db
   ```

3. **クローリングエラー**
   ```bash
   # ネットワーク確認
   curl -I https://www3.nhk.or.jp/news/
   ```

## ライセンス

MIT License

## 貢献

Pull Request、Issue報告を歓迎します。

## サポート

問題や質問がある場合は、Issueを作成してください。