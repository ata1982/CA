-- News AI Database Schema

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Articles table
CREATE TABLE IF NOT EXISTS articles (
    id SERIAL PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    content TEXT NOT NULL,
    summary TEXT,
    original_url VARCHAR(1000),
    author VARCHAR(200),
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_published BOOLEAN DEFAULT FALSE,
    view_count INTEGER DEFAULT 0,
    category_id INTEGER REFERENCES categories(id)
);

-- Crawl sources table
CREATE TABLE IF NOT EXISTS crawl_sources (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) UNIQUE NOT NULL,
    url VARCHAR(1000) NOT NULL,
    selector VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    last_crawled TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_category_id ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_is_published ON articles(is_published);
CREATE INDEX IF NOT EXISTS idx_articles_created_at ON articles(created_at DESC);

-- Insert default categories
INSERT INTO categories (name, description) VALUES 
    ('政治', '政治関連のニュース'),
    ('経済', '経済・ビジネス関連のニュース'),
    ('社会', '社会問題・事件のニュース'),
    ('国際', '国際情勢のニュース'),
    ('スポーツ', 'スポーツ関連のニュース'),
    ('技術', '技術・IT関連のニュース'),
    ('エンターテイメント', 'エンタメ・芸能のニュース'),
    ('その他', 'その他のニュース')
ON CONFLICT (name) DO NOTHING;

-- Insert sample crawl sources
INSERT INTO crawl_sources (name, url, selector, is_active) VALUES 
    ('NHK News', 'https://www3.nhk.or.jp/news/', '.content--list-item', TRUE),
    ('Yahoo News', 'https://news.yahoo.co.jp/', '.newsFeed_item', TRUE),
    ('Reuters', 'https://www.reuters.com/world/', '.story-card', TRUE)
ON CONFLICT (name) DO NOTHING;