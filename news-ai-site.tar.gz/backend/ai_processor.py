import httpx
import asyncio
import json
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import select
from models import Article, Category
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ClaudeProcessor:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            logger.warning("ANTHROPIC_API_KEY not found. Claude processing will be disabled.")
        
        self.client = httpx.AsyncClient(
            base_url="https://api.anthropic.com",
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            } if self.api_key else {},
            timeout=60.0
        )
    
    async def process_article(self, article: Article) -> Dict[str, str]:
        """記事をClaude APIで処理して要約・分析"""
        if not self.api_key:
            return self._mock_processing(article)
        
        try:
            # Prepare prompt
            prompt = f"""
以下のニュース記事を分析してください：

タイトル: {article.title}
内容: {article.content}

以下の形式でJSONレスポンスを返してください：
{{
    "summary": "記事の要約（100文字程度）",
    "category": "記事のカテゴリ（政治/経済/社会/国際/スポーツ/技術/エンターテイメント/その他）",
    "keywords": ["キーワード1", "キーワード2", "キーワード3"],
    "sentiment": "記事の感情（positive/neutral/negative）",
    "importance": "重要度（1-5の数値）"
}}
"""
            
            response = await self.client.post("/v1/messages", json={
                "model": "claude-3-sonnet-20240229",
                "max_tokens": 1000,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            })
            
            response.raise_for_status()
            result = response.json()
            
            # Extract and parse Claude's response
            content = result["content"][0]["text"]
            
            # Try to extract JSON from response
            try:
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                if json_start != -1 and json_end != -1:
                    parsed_data = json.loads(content[json_start:json_end])
                    return parsed_data
            except json.JSONDecodeError:
                logger.error("Failed to parse Claude response as JSON")
                return self._mock_processing(article)
            
        except Exception as e:
            logger.error(f"Error processing article with Claude: {str(e)}")
            return self._mock_processing(article)
    
    def _mock_processing(self, article: Article) -> Dict[str, str]:
        """Claude APIが利用できない場合のモック処理"""
        # Simple keyword-based categorization
        title_content = (article.title + " " + article.content).lower()
        
        category = "その他"
        if any(word in title_content for word in ["政治", "政府", "選挙", "国会"]):
            category = "政治"
        elif any(word in title_content for word in ["経済", "株価", "企業", "ビジネス"]):
            category = "経済"
        elif any(word in title_content for word in ["スポーツ", "野球", "サッカー", "オリンピック"]):
            category = "スポーツ"
        elif any(word in title_content for word in ["技術", "AI", "デジタル", "IT"]):
            category = "技術"
        
        return {
            "summary": article.content[:100] + "..." if len(article.content) > 100 else article.content,
            "category": category,
            "keywords": ["ニュース", "情報", "記事"],
            "sentiment": "neutral",
            "importance": "3"
        }
    
    async def enhance_article(self, article: Article, db: Session) -> Article:
        """記事をAI処理で強化"""
        try:
            analysis = await self.process_article(article)
            
            # Update article with AI analysis
            article.summary = analysis.get("summary", article.summary)
            
            # Set category
            category_name = analysis.get("category", "その他")
            category = db.execute(
                select(Category).where(Category.name == category_name)
            ).scalar_one_or_none()
            
            if not category:
                # Create new category if it doesn't exist
                category = Category(name=category_name)
                db.add(category)
                db.flush()  # Get the ID
            
            article.category_id = category.id
            
            logger.info(f"Enhanced article: {article.title[:50]}...")
            return article
            
        except Exception as e:
            logger.error(f"Error enhancing article: {str(e)}")
            return article
    
    async def batch_process_articles(self, db: Session, limit: int = 10) -> int:
        """未処理の記事を一括でAI処理"""
        # Get articles without summaries or categories
        articles = db.execute(
            select(Article)
            .where(Article.summary.is_(None) | Article.category_id.is_(None))
            .limit(limit)
        ).scalars().all()
        
        processed_count = 0
        
        for article in articles:
            enhanced_article = await self.enhance_article(article, db)
            if enhanced_article:
                processed_count += 1
        
        db.commit()
        logger.info(f"Processed {processed_count} articles")
        return processed_count
    
    async def generate_news_summary(self, articles: List[Article]) -> str:
        """複数記事から総合的なニュース要約を生成"""
        if not self.api_key or not articles:
            return "今日のニュース要約が生成されました。"
        
        try:
            # Prepare articles summary
            articles_text = "\n".join([
                f"- {article.title}: {article.summary or article.content[:100]}"
                for article in articles[:10]  # Limit to 10 articles
            ])
            
            prompt = f"""
以下の記事から今日の重要なニュースの総合要約を作成してください：

{articles_text}

300文字程度で、主要なトピックをまとめてください。
"""
            
            response = await self.client.post("/v1/messages", json={
                "model": "claude-3-sonnet-20240229",
                "max_tokens": 500,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            })
            
            response.raise_for_status()
            result = response.json()
            
            return result["content"][0]["text"]
            
        except Exception as e:
            logger.error(f"Error generating news summary: {str(e)}")
            return "今日のニュース要約が生成されました。"
    
    async def close(self):
        """クライアントを終了"""
        await self.client.aclose()

# Initialize default categories
def init_categories(db: Session):
    """デフォルトカテゴリを初期化"""
    default_categories = [
        {"name": "政治", "description": "政治関連のニュース"},
        {"name": "経済", "description": "経済・ビジネス関連のニュース"},
        {"name": "社会", "description": "社会問題・事件のニュース"},
        {"name": "国際", "description": "国際情勢のニュース"},
        {"name": "スポーツ", "description": "スポーツ関連のニュース"},
        {"name": "技術", "description": "技術・IT関連のニュース"},
        {"name": "エンターテイメント", "description": "エンタメ・芸能のニュース"},
        {"name": "その他", "description": "その他のニュース"}
    ]
    
    for cat_data in default_categories:
        existing = db.execute(
            select(Category).where(Category.name == cat_data["name"])
        ).scalar_one_or_none()
        
        if not existing:
            category = Category(**cat_data)
            db.add(category)
    
    db.commit()

# Example usage
async def main():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    
    engine = create_engine("sqlite:///./news.db")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    
    # Initialize categories
    init_categories(db)
    
    # Process articles
    processor = ClaudeProcessor()
    try:
        count = await processor.batch_process_articles(db)
        print(f"Processed {count} articles")
    finally:
        await processor.close()
        db.close()

if __name__ == "__main__":
    asyncio.run(main())