import httpx
import asyncio
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session
from sqlalchemy import select
from models import Article, Category, CrawlSource
from datetime import datetime
from typing import List, Dict, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NewsCrawler:
    def __init__(self, db: Session):
        self.db = db
        self.client = httpx.AsyncClient(timeout=30.0)
    
    async def crawl_source(self, source: CrawlSource) -> List[Dict]:
        """特定のソースからニュースを収集"""
        try:
            response = await self.client.get(source.url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            articles = []
            
            # Basic news extraction (can be customized per source)
            if source.selector:
                article_elements = soup.select(source.selector)
            else:
                # Default selectors for common news sites
                article_elements = soup.find_all(['article', 'div'], class_=['news-item', 'article', 'post'])
            
            for element in article_elements[:10]:  # Limit to 10 articles per source
                article_data = self._extract_article_data(element, source.url)
                if article_data:
                    articles.append(article_data)
            
            # Update last crawled time
            source.last_crawled = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Crawled {len(articles)} articles from {source.name}")
            return articles
            
        except Exception as e:
            logger.error(f"Error crawling {source.name}: {str(e)}")
            return []
    
    def _extract_article_data(self, element, base_url: str) -> Optional[Dict]:
        """HTML要素から記事データを抽出"""
        try:
            title_elem = element.find(['h1', 'h2', 'h3', 'h4'])
            if not title_elem:
                return None
            
            title = title_elem.get_text(strip=True)
            if len(title) < 10:  # Too short title
                return None
            
            # Extract content
            content_elem = element.find(['p', 'div'], class_=['content', 'summary', 'excerpt'])
            content = content_elem.get_text(strip=True) if content_elem else title
            
            # Extract link
            link_elem = element.find('a', href=True)
            url = link_elem['href'] if link_elem else None
            if url and not url.startswith('http'):
                url = f"{base_url.rstrip('/')}/{url.lstrip('/')}"
            
            return {
                'title': title,
                'content': content,
                'original_url': url,
                'summary': content[:200] + '...' if len(content) > 200 else content
            }
            
        except Exception as e:
            logger.error(f"Error extracting article data: {str(e)}")
            return None
    
    async def crawl_all_sources(self) -> int:
        """全てのアクティブなソースから記事を収集"""
        sources = self.db.execute(
            select(CrawlSource).where(CrawlSource.is_active == True)
        ).scalars().all()
        
        total_articles = 0
        
        for source in sources:
            articles = await self.crawl_source(source)
            
            # Save articles to database
            for article_data in articles:
                # Check if article already exists
                existing = self.db.execute(
                    select(Article).where(Article.title == article_data['title'])
                ).scalar_one_or_none()
                
                if not existing:
                    article = Article(
                        title=article_data['title'],
                        content=article_data['content'],
                        summary=article_data['summary'],
                        original_url=article_data['original_url'],
                        is_published=True,
                        published_at=datetime.utcnow()
                    )
                    self.db.add(article)
                    total_articles += 1
        
        self.db.commit()
        logger.info(f"Total new articles added: {total_articles}")
        return total_articles
    
    async def close(self):
        """クローラーを終了"""
        await self.client.aclose()

# Sample sources initialization
def init_sample_sources(db: Session):
    """サンプルのニュースソースを初期化"""
    sample_sources = [
        {
            'name': 'NHK News',
            'url': 'https://www3.nhk.or.jp/news/',
            'selector': '.content--list-item'
        },
        {
            'name': 'Yahoo News',
            'url': 'https://news.yahoo.co.jp/',
            'selector': '.newsFeed_item'
        },
        {
            'name': 'Reuters',
            'url': 'https://www.reuters.com/world/',
            'selector': '.story-card'
        }
    ]
    
    for source_data in sample_sources:
        existing = db.execute(
            select(CrawlSource).where(CrawlSource.name == source_data['name'])
        ).scalar_one_or_none()
        
        if not existing:
            source = CrawlSource(**source_data)
            db.add(source)
    
    db.commit()

# Example usage
async def main():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    
    engine = create_engine("sqlite:///./news.db")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    
    # Initialize sample sources
    init_sample_sources(db)
    
    # Run crawler
    crawler = NewsCrawler(db)
    try:
        count = await crawler.crawl_all_sources()
        print(f"Crawled {count} new articles")
    finally:
        await crawler.close()
        db.close()

if __name__ == "__main__":
    asyncio.run(main())