from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
from typing import List, Optional
import os

from models import Base, Article, Category, CrawlSource

# Database setup
DATABASE_URL = "sqlite:///./news.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="News AI Site", version="1.0.0")

# Templates and static files
templates = Jinja2Templates(directory="../frontend")
app.mount("/static", StaticFiles(directory="../frontend"), name="static")

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Pydantic models
class ArticleCreate(BaseModel):
    title: str
    content: str
    summary: Optional[str] = None
    original_url: Optional[str] = None
    author: Optional[str] = None
    category_id: Optional[int] = None

class ArticleResponse(BaseModel):
    id: int
    title: str
    content: str
    summary: Optional[str]
    author: Optional[str]
    category: Optional[str]
    view_count: int
    published_at: Optional[str]
    
    class Config:
        from_attributes = True

class CategoryCreate(BaseModel):
    name: str
    description: Optional[str] = None

# API Routes
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request, db: Session = Depends(get_db)):
    articles = db.execute(select(Article).where(Article.is_published == True).order_by(Article.created_at.desc()).limit(10)).scalars().all()
    categories = db.execute(select(Category)).scalars().all()
    return templates.TemplateResponse("index.html", {
        "request": request, 
        "articles": articles, 
        "categories": categories
    })

@app.get("/article/{article_id}", response_class=HTMLResponse)
async def read_article(article_id: int, request: Request, db: Session = Depends(get_db)):
    article = db.execute(select(Article).where(Article.id == article_id)).scalar_one_or_none()
    if article is None:
        raise HTTPException(status_code=404, detail="Article not found")
    
    # Increment view count
    article.view_count += 1
    db.commit()
    
    return templates.TemplateResponse("article.html", {
        "request": request, 
        "article": article
    })

@app.get("/api/articles", response_model=List[ArticleResponse])
async def get_articles(skip: int = 0, limit: int = 10, category_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = select(Article).where(Article.is_published == True)
    if category_id:
        query = query.where(Article.category_id == category_id)
    
    articles = db.execute(query.offset(skip).limit(limit).order_by(Article.created_at.desc())).scalars().all()
    return articles

@app.post("/api/articles", response_model=ArticleResponse)
async def create_article(article: ArticleCreate, db: Session = Depends(get_db)):
    db_article = Article(**article.dict())
    db.add(db_article)
    db.commit()
    db.refresh(db_article)
    return db_article

@app.get("/api/categories")
async def get_categories(db: Session = Depends(get_db)):
    categories = db.execute(select(Category)).scalars().all()
    return categories

@app.post("/api/categories")
async def create_category(category: CategoryCreate, db: Session = Depends(get_db)):
    db_category = Category(**category.dict())
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    return db_category

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)